import React from 'react';
import axios from 'axios';

export default class Posts extends React.Component{
    render(){
        return <h1>Posts Component !</h1>
    }

}