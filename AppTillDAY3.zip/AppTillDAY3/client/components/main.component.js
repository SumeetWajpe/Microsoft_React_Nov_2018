import React from 'react';
import {Link} from 'react-router'

export default class MainComponent extends React.Component{
    render(){
        return <div>

            <Link to="/" className="btn btn-primary"> Users</Link>
            <Link to="/posts" className="btn btn-primary"> Posts</Link>

            <h1> Main Component !</h1>           
            {React.cloneElement(this.props.children)}
            </div>
    }
}