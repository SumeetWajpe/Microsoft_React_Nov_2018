export function AddUser(){
    return{
        type:'ADD_USER'
    }
}
export function RemoveUser(){
    return{
        type:'REMOVE_USER'
    }
}

export function IncrementFollowers(){
    return{
        type:'INCREMENT_FOLLOWERS'
    }
}

export function RemovePost(){
    return{
        type:'REMOVE_POST'
    }
}




