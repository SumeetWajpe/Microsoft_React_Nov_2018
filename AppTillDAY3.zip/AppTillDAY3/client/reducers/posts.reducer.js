export default function posts(defState=[],action){
    

   switch (action.type) {
       case 'REMOVE_POST':
                    console.log('Within Posts Reducer !');
                    console.log(defState);                   
                    return defState; // return a new State !          
       default:
           return defState;
   }

}