export default function users(defState=[],action){

    switch (action.type) {
        case 'ADD_USER':
                     console.log('Within Users Reducer ! case : ADD_USER');
                    console.log(defState);
                     return defState; // return a new State !   
        case 'INCREMENT_FOLLOWERS':
                     console.log('Within Users Reducer ! case : INCREMENT_FOLLOWERS');
                     console.log(defState);
                   
                     return defState; // return a new State !          
        default:
            return defState;
    }
}