import users from './users.reducer';
import posts from "./posts.reducer";
import {combineReducers} from 'redux';

var rootReducer = combineReducers({
    posts,users
});

export default rootReducer;