import {createStore} from 'redux';
import rootReducer from '../reducers/rootReducer';
import users from '../data/users';

var defaultStoreData = {
   posts:[{id:1,name:'article'}],
   users:users
};


//createStore(rootReducer,defaultStoreData)

var store = createStore(rootReducer,defaultStoreData)
export default store;