import React from 'react';

export default props => (
  <button onClick={props.onClick}>{props.label}</button>
);
