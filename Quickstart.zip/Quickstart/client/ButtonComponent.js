import React from 'react';

export default class ButtonComponent extends React.Component{
    constructor(props){
        super(props);
         this.state = {currCount:this.props.count}
    }
    
    HandleClick(){          
           this.setState({currCount:this.state.currCount+1});// change State -> pass a new state !
    }
    
    render(){
        return <div>
           <button 
        onClick={this.HandleClick.bind(this)}
        className="btn btn-success">{this.state.currCount}</button>
         </div>
    }
}

export const PI = 3.14;