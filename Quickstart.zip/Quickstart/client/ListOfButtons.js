import React from 'react';
import ReactDOM from 'react-dom';

import ButtonComponent from './ButtonComponent'

export default class ButtonList extends React.Component{
    

    constructor(props){
        super(props);
        this.state = {buttonList:this.props.list}
    }
    AddButtonHandler(){
                // access the textbox !
                // read the value from textbox !
                var newValue = 
                +(ReactDOM.findDOMNode(this.refs.inputValue).value);
               
                this.setState({
                    buttonList:[...this.state.buttonList,newValue]
                 });
    }
    DeleteButtonHandler(){       
        var txtValue = +(ReactDOM.findDOMNode(this.refs.inputValue).value);
        var indexToBeDeleted = this.state.buttonList.findIndex(d => d == txtValue )
        
          var tempArray = [...this.state.buttonList];
                tempArray.splice(indexToBeDeleted,1);
                this.setState({buttonList:tempArray});     
                }
    
    render(){

        console.log(this.state.buttonList);

        var buttonsToBeCreated = this.state.buttonList.map(
            (c,i) => <ButtonComponent count={c} key={i} />
        )

        return <div>

                New Value : <input type="text" ref="inputValue"/>
                 <input type="button" className="btn btn-primary" value="Add !"
                 onClick={this.AddButtonHandler.bind(this)}
                 />

                  <input type="button" className="btn btn-primary"
                   value="Delete !"
                 onClick={this.DeleteButtonHandler.bind(this)}
                 />

                             {buttonsToBeCreated}
                    </div>
    }
}