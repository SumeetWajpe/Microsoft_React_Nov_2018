// Code Here
import React from 'react';
import ReactDOM from 'react-dom';
import BasicComponent from './BasicComponent';
import LifeCycleComponent from './lifecyclehookups';

import ButtonComponent from './ButtonComponent';
import ButtonList from './ListOfButtons';
import Posts from './PostsComponent';



// ReactDOM.render(<BasicComponent/>,
//     document.getElementById('content'))




// ReactDOM.render(<ButtonList list={[10,20,30,40,50]} />,
//     document.getElementById('content'))


ReactDOM.render(<LifeCycleComponent  />,
    document.getElementById('content'))

    