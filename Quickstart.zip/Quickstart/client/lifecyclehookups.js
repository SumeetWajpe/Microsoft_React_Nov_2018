import React from 'react';
import ReactDOM from 'react-dom';

export default class LifeCycleComponent extends React.Component{
   

    constructor(props){
        super(props);
        this.state = {companyName:''}
    }

    componentWillMount(){
                // initialization
                console.log('Within componentWillMount !');
                }   
    componentDidMount(){
        // access DOM, Make AJAX request !
        console.log('Within componentDidMount !');
    }
    KeyUpHandler(){
        console.log('Key up !')
        var txtCompanyValue = ReactDOM.findDOMNode(this.refs.txtCompanyInput).value;
        this.setState({companyName:txtCompanyValue})
    }

    DeleteAComponent(){
        ReactDOM.unmountComponentAtNode(document.getElementById('content'))
    }

    render(){
        console.log('Within Render !');
        console.log(this.state);

        return <div>
                <h1>{this.state.companyName}</h1>
        Enter Company Name : <input ref="txtCompanyInput" type="text"  onKeyUp={this.KeyUpHandler.bind(this)}
                />

                <button className="btn btn-warning" onClick={this.DeleteAComponent.bind(this)}>
                    <span className="glyphicon glyphicon-trash"></span>
                </button>
        </div>
    }
    shouldComponentUpdate(){
        console.log('Within shouldComponentUpdate !');
        // console.log(arguments);
        // console.log(this.state);

        if(arguments[1].companyName.length > 10){
            return false;
        }
        return true;
    }
    componentWillUpdate(){
        console.log('Within componentWillUpdate !');
        // console.log(this.state);

    }
    componentDidUpdate(){
        console.log('Within componentDidUpdate !');

    }
    componentWillUnmount(){
        // called just before instance gets removed from DOM !
        console.log('Clean Up Here !')
    }












}