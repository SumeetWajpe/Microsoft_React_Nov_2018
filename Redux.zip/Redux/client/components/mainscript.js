import {connect} from 'react-redux';
import * as AllActions from '../actions/actionCreators';
import Main from './main.component';
import store from '../store/store';
import {bindActionCreators} from 'redux';

// Bind Store as props
function mapStateToProps(storeData){
        return{
            allposts:storeData.posts,
            allusers:storeData.users
        }
}

// Bind action Creators as props
function mapDispatchToProps(dispatcher){
            return bindActionCreators(AllActions,dispatcher);
}

var app = connect(mapStateToProps,mapDispatchToProps)(Main);

export default app;