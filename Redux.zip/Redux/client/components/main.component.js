import React from 'react';
import {Link} from 'react-router'

export default class MainComponent extends React.Component{
    
    componentDidMount(){
        this.props.FetchUsers();
    }
    render(){
        return <div>
            
            <nav className="navbar navbar-inverse">
  <div className="container-fluid">
    <div className="navbar-header">
      <a className="navbar-brand" href="#">Git Hub Users</a>
    </div>
    <ul className="nav navbar-nav">
      
      <li><Link to="/" > Users</Link></li>
      <li> <Link to="/posts"> Posts</Link>
</li>
    </ul>
    <ul className="nav navbar-nav navbar-right">
      <li><a href="#"><span className="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="#"><span className="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>

            {React.cloneElement(this.props.children,this.props)}
            </div>
    }
}