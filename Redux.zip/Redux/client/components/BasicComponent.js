import React from 'react';

export default class BasicComponent extends React.Component{
    render(){
        return <h1> JSX in Component !</h1>
    }
}