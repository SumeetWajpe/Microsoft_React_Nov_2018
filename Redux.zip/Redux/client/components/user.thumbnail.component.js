import React from 'react';
import {Link} from 'react-router';

export default class UserThumbnail extends React.Component{
    render(){
     
        return <div className="col-md-3 userStyle">                
                <div className="container-fluid">
                    <div className="row">
                    <div className="col-md-10">
                                  <Link to={`/user/${this.props.userDetail.id}`}>
                                    <img 
                                     src={this.props.userDetail.avatar_url}
                                     className="img-thumbnail"
                                     />
                                  </Link> 
                            </div>                            
                    </div>
                    <div className="row justify-content-between">
                    <div className="col-md-3">
                                  <h4> {this.props.userDetail.login} </h4>    
                            </div>
                    
                    <div className="col-md-6">
                                 <button className="btn btn-primary"
                                 onClick={this.props.IncrementFollowers.bind(this,this.props.userIndex)}
                                 >
                                        <span className="glyphicon glyphicon-user"></span>
                                
                                {this.props.userDetail.followers}
                                </button>  
                            </div>                    
                </div>
                </div>
        </div>
        
       
    }
}