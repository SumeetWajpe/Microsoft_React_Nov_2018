import React from 'react';

export default class UserDetails extends React.Component{
    render(){
     console.log(this.props.allusers);
        // Fetch the value from Url !
        let theUserId = this.props.params.id; // for react router 2.0
        // let theUserId = this.props.match.params.id; // for react router 3.0


            let currUser = this.props.allusers.find(
                u => {
                    if(u.id  == theUserId){
                        return true;
                    }
                }
            )


        return <div>
            <h1> User Details for {currUser.id}!</h1>
            <div className="container">
                    <div className="row">
                        <div className="col-md-6">
                            <img src={currUser.avatar_url} />
                        </div>
                        <div className="col-md-6">
                            
                            Login : {currUser.login} <br/>
                            Is Admin : {currUser.site_admin} <br/>
                            Type : {currUser.type} <br/>
                            Followers : {currUser.followers}

                            
                        </div>
                    </div>

            </div>
            </div>
      
        
       
    }
}