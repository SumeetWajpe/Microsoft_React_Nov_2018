import React from 'react';
import UserThumbnail from './user.thumbnail.component';

export default class UsersComponent extends React.Component{
    render(){
      

        var usersToBeCreated = this.props.allusers.map(
            (user,index) => <UserThumbnail 
            {...this.props} 
            userDetail={user}
            userIndex={index}
            key={user.id}
            />
        )

        return <div className="container">

                    <div className="jumbotron">
                    <h1> All Github Users </h1>

                    </div>

<div className="container-fluid">
            <div className="row">
                         {usersToBeCreated}
            </div>
</div>
                      
        </div> 
    }
}