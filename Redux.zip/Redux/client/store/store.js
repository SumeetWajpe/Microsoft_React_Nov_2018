import {createStore,applyMiddleware} from 'redux';
import rootReducer from '../reducers/rootReducer';
import users from '../data/users';
import thunk from 'redux-thunk';
 

// var defaultStoreData = {
//    posts:[{id:1,name:'article'}],
//    users:users
// };


//createStore(rootReducer,defaultStoreData)

var store = createStore(rootReducer,applyMiddleware(thunk))
export default store;