// Code Here
import React from 'react';
import ReactDOM from 'react-dom';
import BasicComponent from './components/BasicComponent';
import Posts from './components/PostsComponent';

import {Router,Route,IndexRoute,browserHistory} from 'react-router';
import MainComponent from './components/main.component';
import UsersComponent from './components/users.component';
import UserDetails from './components/user.details.component';

import store from './store/store';
import {Provider} from 'react-redux';
import app from './components/mainscript';

var router = <Provider store={store}> 
                    <Router history={browserHistory}>
                         <Route path="/" component={app}>
                                <IndexRoute component={UsersComponent}></IndexRoute>
                                   <Route path="/posts" component={Posts}>
                                   </Route>
                                   <Route path="/user/:id" component={UserDetails}>
                                   </Route>
                 </Route>
</Router>
</Provider>

ReactDOM.render(router,
    document.getElementById('content'))


    