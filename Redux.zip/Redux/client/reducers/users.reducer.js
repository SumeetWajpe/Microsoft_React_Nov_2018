export default function users(defState=[],action){

    switch (action.type) {
        case 'ADD_USER':
                     console.log('Within Users Reducer ! case : ADD_USER');
                    console.log(defState);
                     return defState; // return a new State !   
        case 'INCREMENT_FOLLOWERS':
                  var index = action.index;
                // increment the follower ?
              
                return [
                        ...defState.slice(0,index),
                        {...defState[index],followers:defState[index].followers + 1},
                        ...defState.slice(index+1)
                ];

                case 'FETCH_USERS':
                console.log(action)
                return action.response;

        default:
            return defState;
    }
}